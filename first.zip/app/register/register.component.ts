import { Component, OnInit } from '@angular/core';
import { RegisterDetails } from '../user/model/user.model';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  firstName: any = '';
  lastName: any = '';
  mobile: any = '';
  gender: any = '';
  userName: any = '';
  userPassword: any = '';
  registerDetails: RegisterDetails = new RegisterDetails('','','','','','');

  constructor() { }

  ngOnInit(): void {
  }

  registerMe(): void {
    console.log(this.registerDetails);
    alert(" FirstName: "+ this.registerDetails.firstName + 
    " LastName: "+ this.registerDetails.lastName + 
    " Mobile: "+ this.registerDetails.mobile +
      "userName:"+ this.registerDetails.userName +
    " Password: "+ this.registerDetails.password);
  }

}
