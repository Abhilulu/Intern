import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { from } from 'rxjs';
import { EventHandlingComponent } from './event-handling/event-handling.component';
import { FirstComponent } from './first/first.component';
import { LoginComponent } from './user/login/login.component';
import {RegisterComponent} from './register/register.component';
const routes: Routes = [
  {
    path: '',
    component: FirstComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'events',
    component: EventHandlingComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
