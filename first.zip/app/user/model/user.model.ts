export class LoginDetails {
    constructor(
        public userName: string,
        public password: string
    ){}
}


export class RegisterDetails {
    constructor(
        public userName: string,
        public password: string,
        public firstName: string,
        public lastName: string,
        public mobile: string,
        public gender: string,
    ){}
}