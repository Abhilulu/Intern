import { Component, OnInit } from '@angular/core';
import { LoginDetails } from '../model/user.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userName: any = '';
  userPassword: any = '';
  loginDetails: LoginDetails = new LoginDetails('','');

  constructor() { }

  ngOnInit(): void {
  }


  loginMe(): void {
    console.log(this.loginDetails);
    alert("userName:"+ this.loginDetails.userName + " and Password: "+ this.loginDetails.password);
  }

}
