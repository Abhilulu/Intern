import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'student-mngt';
  name = "Aman Kumar";
  getName()
  {
    return "Aman"
  }

obj={
  name:'Kumar',
  age:20
}

arr=['Aman','Ravi','Vishal']

a=50;
b=60;

siteUrl=window.location.href 

getName1()
{
  alert("Aman")
}



}
